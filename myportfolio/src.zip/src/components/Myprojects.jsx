import React, { useState } from "react";

import "../styles/myprojects.css";

import bewakoof from "../images/bewakoof.png";
import fashion from "../images/fashion.png";
import theoutnet from "../images/theoutnet.png";
import indeeed from "../images/indeeed.png";



const Myprojects = () => {
  const [links2, setLinks2] = useState(false);
  const [links3, setLinks3] = useState(false);

  return (
    <div id="myProjects_main">
      <h1
        className="myProjects_heading__phVYz"
        style={{ color: "rgb(204, 214, 246)" }}
      >
        My Projects
      </h1>
      <div className="myProjects_borderBottom__RLbe1"></div>

      {/* 1st proj */}
      <div
        id="about"
        className="Home_experience__g58MS"
        style={{ background: "rgb(15, 22, 34)" }}
      >
        <div
          onMouseEnter={() => setLinks2(true)}
          onMouseLeave={() => {
            setLinks2(false);
          }}
          className="About_container__63eab"
          style={{ boxShadow: "rgb(36, 36, 58) 3px 3px 5px" }}
        >
          <div className="About_first__P-0xg">
            <img style={{"borderRadius":"10px"}} src={fashion} alt="" />
          </div>

          {links2 && (
            <div
              id="projectLinks"
              style={{
                backgroundColor: "rgb(12, 20, 27)",
                boxShadow: "rgb(36, 36, 58) 3px 3px 5px",
                borderRadius: "15px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  margin: "auto",
                  width: "9rem",
                  height: "4.5rem",
                  padding: "0.5rem",
                  justifyContent: "center",
                }}
              >
                <div id="git">
                  <a
                    href="https://github.com/agodse21/agonizing-cable-172"
                    target="_blank"
                  >
                    <span className="iconify" data-icon="feather:github"></span>
                  </a>
                </div>
                <div id="gotoProject">
                  <a
                    href="https://frontend-eight-lime.vercel.app/"
                    target="_blank"
                  >
                    <span class="iconify" data-icon="bx:link-external"></span>
                  </a>
                </div>
              </div>
            </div>
          )}

          <div className="About_second__g9Cy4">
            <h2
              className="About_heading__HT8z+"
              style={{ color: "rgb(204, 214, 246)" }}
            >
              Asos.com Clone
            </h2>
            <div className="About_borderBottom__C8CzR"></div>
            <p
              className="About_aboutMe__Kx5NY"
              style={{ color: "rgb(137, 147, 177)" }}
            >
        
              ASOS is a Men and Women's fashion brand for the newest & trending Cloths,fashion
               accessories and online shop that offered high quality products 
              at an affordable price. We have built the exact website clone as it is on the 
              original website.
              <br />
             
              I was handling the front-end part and created a Landing page with responsive
               and Footer page.
              <br />
              <br />
              <span style={{ color: "rgb(0, 160, 160)" }}>  
              {" "}Tech-Stacks </span> we used to build the clone are
              <span style={{ color: "rgb(0, 160, 160)" }}>
                {" "} ReactJs | Redux | Mongodb | Express | NodeJs|
                Javascript | HTML5 | CSS3 | GitHub 
              </span>
              .
            </p>
          </div>
        </div>
      </div>
      {/* 2nd Project */}
        <div
        id="about"
        className="Home_experience__g58MS"
        style={{ background: "rgb(15, 22, 34)" }}
      >
        <div
          onMouseEnter={() => setLinks2(true)}
          onMouseLeave={() => {
            setLinks2(false);
          }}
          className="About_container__63eab"
          style={{ boxShadow: "rgb(36, 36, 58) 3px 3px 5px" }}
        >
          <div className="About_first__P-0xg">
            <img style={{"borderRadius":"10px"}}   src={theoutnet} alt="" />
          </div>

          {links2 && (
            <div
              id="projectLinks"
              style={{
                backgroundColor: "rgb(12, 20, 27)",
                boxShadow: "rgb(36, 36, 58) 3px 3px 5px",
                borderRadius: "15px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  margin: "auto",
                  width: "9rem",
                  height: "4.5rem",
                  padding: "0.5rem",
                  justifyContent: "center",
                }}
              >
                <div id="git">
                  <a
                    href="https://github.com/satyamkumarjha2002/Unit-3-project/tree/master"
                    target="_blank"
                  >
                    <span className="iconify" data-icon="feather:github"></span>
                  </a>
                </div>
                <div id="gotoProject">
                  <a
                    href="https://incomparable-kheer-67acf9.netlify.app/"
                    target="_blank"
                  >
                    <span class="iconify" data-icon="bx:link-external"></span>
                  </a>
                </div>
              </div>
            </div>
          )}

          <div className="About_second__g9Cy4">
            <h2
              className="About_heading__HT8z+"
              style={{ color: "rgb(204, 214, 246)" }}
            >
              Theoutnet.com Clone
            </h2>
            <div className="About_borderBottom__C8CzR"></div>
            <p
              className="About_aboutMe__Kx5NY"
              style={{ color: "rgb(137, 147, 177)" }}
            >
              Theoutnet.com is a leading E-Commerce website for all types of
              clothes, and cosmetic products are available on this website such
              as jeans, trousers, fragrances, shoes, bags, etc. for both men &
              women.
              <br />
              I was handling the front-end part and created a women's product
              page and payment page.
              <br />
              <br />
              <span style={{ color: "rgb(0, 160, 160)" }}>  
              {" "}Tech-Stacks </span> we used to build the clone are
              <span style={{ color: "rgb(0, 160, 160)" }}>
                {" "}
                Javascript | HTML5 | CSS3 | GitHub |Netlify
              </span>
              .
            </p>
          </div>
        </div>
      </div>

{/* 3rd project */}
<div
        id="about"
        className="Home_experience__g58MS"
        style={{ background: "rgb(15, 22, 34)" }}
      >
        <div
          onMouseEnter={() => setLinks3(true)}
          onMouseLeave={() => {
            setLinks3(false);
          }}
          className="About_container__63eab"
          style={{ boxShadow: "rgb(36, 36, 58) 3px 3px 5px" }}
        >
          <div className="About_first__P-0xg">
            <img style={{"borderRadius":"10px"}}  src={indeeed} alt="" />
          </div>

          {links3 && (
            <div
              id="projectLinks"
              style={{
                backgroundColor: "rgb(12, 20, 27)",
                boxShadow: "rgb(36, 36, 58) 3px 3px 5px",
                borderRadius: "15px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  margin: "auto",
                  width: "9rem",
                  height: "4.5rem",
                  padding: "0.5rem",
                  justifyContent: "center",
                }}
              >
                <div id="git">
                  <a
                    href="https://github.com/Chhattoo25/curved-knee-365"
                    target="_blank"
                  >
                    <span className="iconify" data-icon="feather:github"></span>
                  </a>
                </div>
                <div id="gotoProject">
                  <a
                    href="https://indeed-clone-ten.vercel.app/"
                    target="_blank"
                  >
                    <span class="iconify" data-icon="bx:link-external"></span>
                  </a>
                </div>
              </div>
            </div>
          )}

          <div className="About_second__g9Cy4">
            <h2
              className="About_heading__HT8z+"
              style={{ color: "rgb(204, 214, 246)" }}
            >
              Indeed.com Clone
            </h2>
            <div className="About_borderBottom__C8CzR"></div>
            <p
              className="About_aboutMe__Kx5NY"
              style={{ color: "rgb(137, 147, 177)" }}
            >
              Indeed is a American worldwide employment website which is provide a 
              free service to job seekers, where you can search any job from and for your preffered 
              location and you can upload your resume save
               it and create a job alert also to get email. Launched in November 2004.
              <br /> I was handling the front-end part and created  salary guide page,Footer  page.
              <br />
              <br />
              <span style={{ color: "rgb(0, 160, 160)" }}>  
              {" "}Tech-Stacks </span> we used to build the clone are
              <span style={{ color: "rgb(0, 160, 160)" }}>
                {" "}
                ReactJs| Redux | Javascript | HTML5 | CSS3 | GitHub |Vercel
              </span>
              .
            </p>
          </div>
        </div>
      </div>


        {/* 4th project */}
        <div
        id="about"
        className="Home_experience__g58MS"
        style={{ background: "rgb(15, 22, 34)" }}
      >
        <div
          onMouseEnter={() => setLinks3(true)}
          onMouseLeave={() => {
            setLinks3(false);
          }}
          className="About_container__63eab"
          style={{ boxShadow: "rgb(36, 36, 58) 3px 3px 5px" }}
        >
          <div className="About_first__P-0xg">
            <img style={{"borderRadius":"10px"}}  src={bewakoof} alt="" />
          </div>

          {links3 && (
            <div
              id="projectLinks"
              style={{
                backgroundColor: "rgb(12, 20, 27)",
                boxShadow: "rgb(36, 36, 58) 3px 3px 5px",
                borderRadius: "15px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  margin: "auto",
                  width: "9rem",
                  height: "4.5rem",
                  padding: "0.5rem",
                  justifyContent: "center",
                }}
              >
                <div id="git">
                  <a
                    href="https://github.com/rajpawanku/Unit2ProjectBewakoof"
                    target="_blank"
                  >
                    <span className="iconify" data-icon="feather:github"></span>
                  </a>
                </div>
                <div id="gotoProject">
                  <a
                    href="https://radiant-alpaca-ceefd6.netlify.app/"
                    target="_blank"
                  >
                    <span class="iconify" data-icon="bx:link-external"></span>
                  </a>
                </div>
              </div>
            </div>
          )}

          <div className="About_second__g9Cy4">
            <h2
              className="About_heading__HT8z+"
              style={{ color: "rgb(204, 214, 246)" }}
            >
              Bewakoof.com Clone
            </h2>
            <div className="About_borderBottom__C8CzR"></div>
            <p
              className="About_aboutMe__Kx5NY"
              style={{ color: "rgb(137, 147, 177)" }}
            >
              Bewakoof.com is a leading E-Commerce website for all types of
              clothes and mobile accessories products are available on this
              website such as jeans, shirts, mobile covers, shoes, bags, etc.
              for both men & women.
              <br /> I was handling the front-end part and created footer,landing page and payment page.
              <br />
              <br />
              <span style={{ color: "rgb(0, 160, 160)" }}>  
              {" "}Tech-Stacks </span> we used to build the clone are
              <span style={{ color: "rgb(0, 160, 160)" }}>
                {" "}
                Javascript | HTML5 | CSS3 | GitHub |Netlify
              </span>
              .
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Myprojects;
