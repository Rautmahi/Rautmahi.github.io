import React from 'react'
import GitHubCalendar from 'react-github-calendar';
import "../styles/Github.css";
const Github = () => {
  return (
    <section className='Github_main_class'>
      <h1  className="TechStacks_heading__phVYz" style={{"textAlign":"center", "color": "rgb(204, 214, 246)"}}>Days I Code</h1>
      <br />
      <div className='streak_img'>
        <img src="https://github-readme-streak-stats.herokuapp.com/?user=rautmahi&" alt="rautmahi" />
      </div>
      <br />
      <div className='streak_img'>
      <img src="https://github-readme-stats.vercel.app/api?username=rautmahi&show_icons=true&locale=en" alt="rautmahi" />
      </div>  
      <br />
      <div className='github_calender'  >
         <GitHubCalendar className="calender_font" username="rautmahi" year={new Date().getFullYear()} />
      </div>
    </section>
  )
}

export default Github