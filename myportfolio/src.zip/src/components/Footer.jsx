import React from "react";

const Footer = () => {
  return (
    <div>
      <div
        style={{
          textAlign: "center",
          padding: "10px", 
         
        }}
      >
        <span style={{"fontSize":"15px"}}>
          Created By <a href="#">Mahesh Raut</a> |
           2022 All rights reserved.
        </span>
      </div>
    </div>
  );
};

export default Footer;
