import React from "react";
import "../styles/about.css";
const About = () => {
  return (
    <div>
      <div
        id="about"
        className="Home_experience__g58MS"
        style={{ background: "rgb(15, 22, 34)" }}
      >
        <div
          className="About_container__63eab"
          style={{ boxShadow: "rgb(36, 36, 58) 3px 3px 5px" }}
        >
          <div className="About_first__P-0xg">
            <img style={{"borderRadius":"10px"}}
              src="https://media3.giphy.com/media/qgQUggAC3Pfv687qPC/giphy.gif"
              alt=""
            />
          </div>

          <div className="About_second__g9Cy4">
            <h1
              className="About_heading__HT8z+"
              style={{ color: "rgb(204, 214, 246)" }}
            >
              About Me
            </h1>

            <div className="About_borderBottom__C8CzR"></div>
            <br />
            <p
              className="About_aboutMe__Kx5NY"
              style={{ color: "rgb(137, 147, 177)" }}
            >
              {/* A Full Stack Web Developer with a passion for developing web
              applications and working across the full stack. I can handle
              multiple tasks on a daily basis. Also, I use a creative approach
              to problem-solving.
              <br /> A dependable person who is great at time management and
               always energetic and also I have experience working as part of
              a team and individually. */}
              Full Stack Web Developer passionate about developing web
applications and working across the full stack. A proficient programmer
in MERN and JavaScript.<br/> Ability to learn new technologies and software
quickly. also, a dependable person who is excellent at time management.
              <br />
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
